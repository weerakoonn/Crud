export class Employee {
    id: number;
    firstName: string;
    lastName: string;
    emailId: string;
	departmentId:string;
	SupervisorId:string;
	Salary:number;
	Position:string;
	Status:string;
	Address:string;
	Contact:string;
	nic:string;
    active: boolean;
}